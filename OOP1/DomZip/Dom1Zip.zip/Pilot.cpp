#include "Pilot.h"
Pilot::Pilot(string i, int br) :ime(i), brLet(br), leti(false){}

inline string Pilot::getIme() const {
	return ime;

}
inline bool Pilot::getLeti() const {
	return leti;
}
 int Pilot::getBR() const {
	return brLet;
}

 void Pilot::PromeniLeti(bool l)
{
	leti = l;
}

void Pilot::DodajSate(int k)
{
	if (k >= 0) {
		brLet += k;
	}
	else(std::cout << "Nije moguce dodati negativne sate");
}

void Pilot::Pisi()
{
	std::cout << ime << '(' << brLet << ')' <<" -" << (leti ? 'L' : 'N');
}
