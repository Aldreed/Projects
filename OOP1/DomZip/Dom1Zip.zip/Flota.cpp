#include "Flota.h"
#include "Avion.h"
Flota::Flota(string n): naziv(n), brAviona(0),brPutnika(0){}

Flota::Flota(Flota&& t)
{
	prvi = t.prvi;
	t.prvi = nullptr;
};



inline int Flota::getBrojAviona() const
{
	return brAviona;
}

void Flota::Dodaj(Avion& k)
{

	brAviona++;
	brPutnika += k.getBroj();
	if (max == nullptr) {
		max = &k;
	}
	else if (max->getBroj() < k.getBroj()) {
		max = &k;
	}
	Deo* nov = new Deo(k);
	Deo* curr = prvi;
	if (prvi == nullptr) {
		prvi = nov;
	}
	else
	{
		while (curr->nxt)
		{
			curr = curr->nxt;
		}
	curr->nxt = nov;

	}
}

Avion& Flota::getMaxAvion() const
{
	return *max;
}

inline int Flota::getMaxPutnik() const
{
	return brPutnika;
}

void Flota::Ispisi()
{
	std::cout << naziv<<'\n';
	Deo* tek = prvi;
	while (tek)
	{
		tek->obj->Pisi();
		std::cout << '\n';
		tek = tek->nxt;

	}
}

Flota::~Flota()
{
	Deo* curr = prvi;
	Deo* pret = curr;
	while (curr) {
		
		pret = curr;
		curr=curr->nxt;
		delete pret;
	}
}

