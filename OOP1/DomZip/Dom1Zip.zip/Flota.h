#pragma once
#include "Avion.h"
 

class Flota
{
	
	struct Deo
	{
		Avion* obj=nullptr;
		Deo* nxt = nullptr;
		Deo(Avion& r) : obj(&r) {};
	};
	int brAviona=0;
	int brPutnika=0;
	string naziv;
	Deo* prvi=nullptr;
	Avion* max = nullptr;
public:
	Flota(string);	
	Flota(Flota&& t);

	int getBrojAviona()const;
	Avion& getMaxAvion()const;
	int getMaxPutnik() const;


	void Dodaj(Avion&);
	
	void Ispisi();

	~Flota();
	
};	

