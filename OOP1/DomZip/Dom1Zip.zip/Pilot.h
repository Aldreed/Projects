#pragma once
#include <iostream>
using std::string;
class Pilot
{
	string ime;
	bool leti; 
	int brLet;
public:
	Pilot(string, int);
	Pilot(const Pilot&) = delete;
	
	string getIme() const ;
	bool getLeti() const ;
	int getBR() const ;
	
	void PromeniLeti(bool);
	void DodajSate(int);
	void Pisi();
};

