#include "Pilot.h"
#include "Avion.h"
#include "Flota.h"



int main() {

	Flota j("Flyers");

	Pilot p("Lor", 150);
	Pilot k("Evie", 189);
	Pilot d("Andro", 140);
	Pilot u("Emi", 50);
	
	Avion g(200, "The Carrier");
	Avion a(150, "Zogord");
	
	a.setKopilot(u);
	a.setKapetan(p); 
		
	g.setKapetan(k);
	g.setKopilot(d);
	
	j.Dodaj(a);
	j.Dodaj(g);
	j.Ispisi();
	j.getMaxAvion().Pisi();
	


}