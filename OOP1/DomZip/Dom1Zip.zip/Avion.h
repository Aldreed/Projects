#pragma once
#include "Pilot.h"
#include <iostream>

class Avion
{	
	int maxBrojPutnika;
	string naziv;
	Pilot* kapetan;
	Pilot* kopilot;
public:
	Avion(int k, string naziv);
	Avion(const Avion&)=delete;

	int getBroj() const;
	string getIme() const;
	Pilot& getKapetan() const ;
	Pilot& getKopilot() const;
	
	void setKapetan(Pilot&);
	void setKopilot(Pilot&);
	
	void Pisi();

	
};

