
#include "Avion.h"

Avion::Avion(int k, string n): maxBrojPutnika(k), naziv(n), kapetan(nullptr),kopilot(nullptr)
{
}

void Avion::setKapetan(Pilot& p)
{
	if (p.getBR() > 100) {
		kapetan = &p;
		p.PromeniLeti(true);
	}
	else
	{
		std::cout << "Pilot nije postavljen kao kapetan jer nema dovoljan broj sati" << '\n';
	}
}

void Avion::setKopilot(Pilot& m)
{
	kopilot = &m;
	m.PromeniLeti(true);
	
}

void Avion::Pisi()
{
	std::cout << "AVION:" << naziv << " - " << maxBrojPutnika;
}



int Avion::getBroj() const
{
	return maxBrojPutnika;
}

inline string Avion::getIme() const
{
	return naziv;
}

inline Pilot& Avion::getKapetan() const
{	
	return *kapetan;
}

inline Pilot& Avion::getKopilot() const
{
	return *kopilot;
}


