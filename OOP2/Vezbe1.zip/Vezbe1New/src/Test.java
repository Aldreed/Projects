
public class Test {

	public static void writteArray(Point[] pa) {
//		for(int i = 0; i<o.length;i++)
		for(Point p:pa)
			System.out.println(p);
			
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point point = new Point();
		Point point2 = new Point(1,2);
	//	System.out.println("("+ point.getX() + "," + point.getY() +")");
	//	System.out.println(point2);
		
		Point[] pointArray = new Point[3];
		pointArray[0] = point;
		pointArray[1] = point2;
		//pointArray[2] = new Point(4,4);
		
//		pointArray[3] = point; // throw exception
		
		writteArray(pointArray);
		Point p3 = new Point();
		System.out.println(point == p3);
		System.out.println(point.equals(p3));

		String s1 = new String("ABC");
		String s2 = s1;
		String s3 = new String("ABC");
		String s4 = "ABC";
		System.out.println(s2 == s1); // same references
		System.out.println(s1 == s3); // different references
		System.out.println(s1.equals(s3)); // same content
		System.out.println(s1.equals("ABC"));
		System.out.println("ABC" == "ABC");
		System.out.println(s1 == s4);
	}

}
