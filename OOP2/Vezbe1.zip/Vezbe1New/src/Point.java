
public class Point {

	private int x; //set zero-value: 0
	private int y; 
	private static int sx;

	{
		sx = 4;
	}
	static {
		sx = 5;
	}
	
	public Point() {// No-arg constructor 
//		this(0,0); // delegate Point(x,y);
	}  	
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}


	@Override //annotation
	public String toString() {
		//return "(" + x + "," + y + ")";
		StringBuilder sb = new StringBuilder();
		sb.append("(").append(x).append(",").append(y).append(")");
		return sb.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true; //Same object
		if (obj == null)
			return false; // No second object

		if (getClass() != obj.getClass()) // Name of class
			return false; // Is obj Point?
		
		if (!(obj instanceof Point)) // Is Point type
			return false; // Is obj Point?
			
		Point other = (Point) obj; // Need (Point) because pi != po
		//Compare field by field
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}

	
}
