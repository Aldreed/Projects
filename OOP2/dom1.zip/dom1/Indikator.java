package dom1;

public enum Indikator {
	Fiksan(1),Mobilni(2);
	int vrednost;
	Indikator(int k){
		vrednost=k;
	}

}
