package baloni;

import java.awt.Color;

public class Balon extends KruznaFigura {

	public Balon(Vektor v, Color c, double r, Vektor brz, Scena s) {
		super(v, c, r, brz, s);
	}

}
