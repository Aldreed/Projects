package sah;

public abstract class Figura implements Cloneable {
	
	protected Polje polje;
	protected Boja boja;
	
	public enum Boja { CRNA, BELA };
	
	public Figura(Polje polje, Boja boja) {
		this.polje = polje;
		this.boja = boja;
	}
	
	/* NE TREBA AKO JE POLJE PROTECTED (PROTECTED vs PACKAGE)
	public Polje getPolje() {
		return polje;
	}
	*/
	
	// Polimorfizam je podrazumevan
	public boolean mozeDaSePomeri(Polje p, Tabla t) {
		if(polje.equals(p)) return false;
		Figura f = t.dohvatiFiguru(p);
		if(f == null || f.boja != boja) return true;
		return false;
	}
	
	@Override
	public String toString() {
		return "" + (boja == Boja.CRNA ? oznaka() : Character.toUpperCase(oznaka()));
	}

	// Apstraktna metoda
	public abstract char oznaka();
	
	@Override
	public Figura clone() {
		try {
			Figura f = (Figura)super.clone();
			f.polje = new Polje(this.polje.getRed(), this.polje.getKolona());
			return f;
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

}
