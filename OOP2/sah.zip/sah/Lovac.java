package sah;

public class Lovac extends Figura {

	public Lovac(Polje polje, Boja boja) {
		super(polje, boja);
	}

	@Override
	public boolean mozeDaSePomeri(Polje p, Tabla t) {
		return false;
	}
	
	@Override
	public char oznaka() {
		return 'l';
	}

}
