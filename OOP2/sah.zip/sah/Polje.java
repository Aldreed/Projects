package sah;

public class Polje {
	
	private int red;
	private char kolona;
	
	public Polje(int red, char kolona) {
		this.red = red;
		this.kolona = kolona;
	}

	public int getRed() {
		/* PROTECTED vs PACKAGE
		Top t = new Top(this);
		t.polje = this;
		*/
		return red;
	}

	public char getKolona() {
		return kolona;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Polje other = (Polje) obj;
		if (kolona != other.kolona)
			return false;
		if (red != other.red)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(red);
		builder.append(kolona);
		return builder.toString();
	}

}
