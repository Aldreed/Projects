package sah;

public class Top extends Figura {

	public Top(Polje polje, Boja boja) {
		super(polje, boja);
		// this(polje) - NE MOZE I THIS I SUPER
	}
	@Override
	public boolean mozeDaSePomeri(Polje p, Tabla t) {
		/* PROTECTED vs PACKAGE
		Top t = new Top(p);
		Lovac l = new Lovac(p);
		Figura f1 = new Top(p);
		Figura f2 = new Lovac(p);
		polje = p;
		t.polje = p;
		l.polje = p;
		f1.polje = p;
		f2.polje = p;
		*/
		
		// NEPOLIMORFNA referenca super
		if(super.mozeDaSePomeri(p, t) == false) return false;
		if(polje.getKolona() != p.getKolona() && polje.getRed() != p.getRed()) return false;
		
		int dr = (int)Math.signum(p.getRed() - polje.getRed());
		int dk = (int)Math.signum(p.getKolona() - polje.getKolona());
		
		for(int i = polje.getRed() + dr, j = polje.getKolona() - 'A' + dk; ; i += dr, j += dk) {
			if(new Polje(i, (char)(j + 'A')).equals(p)) break;
			Figura f = t.dohvatiFiguru(new Polje(i, (char)(j + 'A')));
			if(f == null) continue;
			return false;
		}
		
		return true;
	}
	
	@Override
	public char oznaka() {
		return 't';
	}

}
