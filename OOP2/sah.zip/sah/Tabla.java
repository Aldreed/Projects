package sah;

public class Tabla implements Cloneable {
	
	private static final int N = 8;
	
	private Figura[][] figure = new Figura[N][N];
	
	public void postavi(Figura f) {
		if(dohvatiFiguru(f.polje) != null) return; 
		figure[f.polje.getRed() - 1][f.polje.getKolona() - 'A'] = f;
	}
	
	public Figura dohvatiFiguru(Polje p) {
		return figure[p.getRed() - 1][p.getKolona() - 'A'];
	}
	
	public void pomeri(Figura f, Polje p) {
		if(!f.mozeDaSePomeri(p, this)) return;
		figure[f.polje.getRed() - 1][f.polje.getKolona() - 'A'] = null;
		figure[p.getRed() - 1][p.getKolona() - 'A'] = f;
		f.polje = p;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		sb.append("  ");
		for(int i = 0; i < N; i++) sb.append((char)('A' + i)).append(' ');
		sb.append('\n');
		for(int i = 0; i < N; i++) {
			sb.append(i + 1).append(' ');
			for(int j = 0; j < N; j++) {
				if(figure[i][j] != null) sb.append(figure[i][j]);
				else sb.append('-');
				sb.append(' ');
			}
			sb.append('\n');
		}
		return sb.toString();
	}
	
	@Override
	protected Tabla clone() {
		try {
			Tabla novatabla = (Tabla)super.clone();
			novatabla.figure = this.figure.clone();
			for(int i = 0; i < N; i++) novatabla.figure[i] = this.figure[i].clone();
			for(int i = 0; i < N; i++) {
				for(int j = 0; j < N; j++) {
					novatabla.figure[i][j] = ((figure[i][j] != null) ? figure[i][j].clone() : null);
				}
			}
			return novatabla;
		} catch (CloneNotSupportedException e) { return null; }
	}

	public static void main(String[] args) {
		
		Tabla tabla = new Tabla();
		
		/*
		 * CLONE nije dostupan u Tabli za Polje jer je protected u Object
		Polje p = new Polje(1, 'A');
		p.clone();
		*/
		
		Figura f1 = new Top(new Polje(3, 'C'), Figura.Boja.BELA);
		Figura f2 = new Top(new Polje(3, 'D'), Figura.Boja.CRNA);
		Figura f3 = new Top(new Polje(6, 'C'), Figura.Boja.CRNA);
		Figura f4 = new Top(new Polje(1, 'C'), Figura.Boja.BELA);

		tabla.postavi(f1);
		tabla.postavi(f2);
		tabla.postavi(f3);
		tabla.postavi(f4);
		
		System.out.println(tabla);
		
		Tabla novatabla = (Tabla)tabla.clone();
		
		tabla.pomeri(f1, new Polje(6, 'C'));
		
		System.out.println(tabla);
		System.out.println(novatabla);

	}

}
