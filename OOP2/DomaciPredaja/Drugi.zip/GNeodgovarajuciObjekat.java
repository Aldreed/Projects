package karting;

public class GNeodgovarajuciObjekat extends Exception {

}
