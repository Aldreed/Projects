package raspored;

public class GVreme extends Exception {
	

}
