package raspored;

public class GIndex extends Exception {

}
