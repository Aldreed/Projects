package raspored;

public class GDodaj extends Exception {

}
