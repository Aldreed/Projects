package pitanja;

public class GNemaPitanja extends Exception {

}
