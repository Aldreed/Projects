/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

/**
 *
 * @author Bogdan
 */
class Stavka {
    int IdPaket = -1;
    int XCord = -1;
    int YCord = -1;
    int Tip = -1;
    int Stavka = -1;
    double Distance = -1;
}
