export default class Media{
    IdMedia:number;
    nekretninaId:number;
    mediaPath:string;
    mediaType:string;
    
   
}