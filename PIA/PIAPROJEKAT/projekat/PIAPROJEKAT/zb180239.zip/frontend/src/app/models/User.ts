export default interface User{
    
    ime:string;
    prezime:string;
    username:string;
    lozinka:string;
    email:string;
    grad:string;
    drzava:string;
    imagePath:string;
    tip:string;
    odobren:boolean;
}