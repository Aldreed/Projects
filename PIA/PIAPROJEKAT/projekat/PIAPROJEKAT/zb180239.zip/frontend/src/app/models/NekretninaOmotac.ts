import Media from "./Media";
import Nekretnina from "./Nekretnina";

export default class NekretninaOmotac{
    nekretnina:Nekretnina;
    media:Media[];
    pickedMedia:string="";
}