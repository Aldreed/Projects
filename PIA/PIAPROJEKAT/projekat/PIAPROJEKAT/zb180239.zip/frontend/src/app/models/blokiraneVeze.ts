export default class blokiiraneVeze{
    IdBlock:number;
    blokirao:string;
    blokiran:string;
    
}