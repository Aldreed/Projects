export default class Prodaja{
    IdPro:number;
    IdNek:number;
    vlasnik:string;
    kupac:string;
    totalCost:number;
    procenat:number;
}