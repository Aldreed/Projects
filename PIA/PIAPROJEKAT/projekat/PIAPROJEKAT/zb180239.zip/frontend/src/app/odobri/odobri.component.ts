import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-odobri',
  templateUrl: './odobri.component.html',
  styleUrls: ['./odobri.component.css']
})
export class OdobriComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
