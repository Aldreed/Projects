export default class Izdavanje{
    IdIzd:number;
    IdNek:number;
    vlasnik:string;
    kupac:string;
    datumOd:Date;
    datumDo:Date;
    totalCost:number;
    procenat:number;
}