export default class Poruka{
    sender:string;
    time:number;
    tipPoruke:string;
    poruka:String;
    tipUser:string;
    prihvacena:string="cekanje";
    cena:number;
    datumOd:string;
    datumTo:string;
    ucesce:number;
}